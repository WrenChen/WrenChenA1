<?php ?>

<!doctype html>
<html>
    <head>
            <title>Thank you!</title>
            <meta charset="utf-8" />
            <link rel="icon" href="images/favicon.ico" />
    </head>

    <body>
        <p>
            Thank you! It has been completed!
            <a href="index.php">Back to Home</a>
        </p>

    </body>
</html>
