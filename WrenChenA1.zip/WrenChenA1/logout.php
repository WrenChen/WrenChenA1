<?php
 session_start();
 session_destroy();
?>
<p>You've logged out</p>
<a href="login.php">Back to login</a>
